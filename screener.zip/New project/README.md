# NSE F&O Scanner Lab

Offline-first stock scanner and strategy builder app for the workflow below:

- Long buildup scanner
- Bollinger squeeze + breakout proximity
- Relative strength leadership scan
- Multi-timeframe scan across 3m, 15m, 1h, and 1d
- Real-time spike detection for price, volume, and OI impulses
- Plug-in live data adapter layer for broker or market-data integration
- Volume profile trade planning
- Order depth confirmation
- ATR-based stop loss
- Pivot-based targets
- 9 EMA trailing exit rule

## Run

Open `index.html` in any browser.

Open `options.html` for the options-specific volatility, PCR, gamma, and flow scanner page.

## Notes

- The current app ships with a broader sample NSE F&O-eligible stock universe so it works offline without feeling limited to Nifty 50 names.
- The final stock selection rule requires a stock to satisfy at least 2 of the 3 scanners.
- "Actionable" status requires scanner qualification, multi-timeframe alignment, order-depth confirmation, and a valid entry model.
- The app includes a mock live adapter and a manual webhook adapter interface. You can extend the adapter registry in `app.js` to plug in a broker or market-data API.
- The app still uses a sample offline F&O universe and simulated live updates by default. To go fully live, connect it to the current NSE F&O list plus your preferred broker or data vendor feed.
- The new options page ranks names using stochastic RSI, Bollinger breakout, Ichimoku cloud, volume profile, IV vs HV, PCR, options flow, gamma exposure, and liquidity filters.

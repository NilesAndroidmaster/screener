const defaultSettings = {
  priceChangeThreshold: 2,
  oiThreshold: 5,
  volumeThreshold: 1.5,
  betaThreshold: 1.2,
  breakoutZoneThreshold: 1,
  bidAskThreshold: 2,
  spikePriceThreshold: 0.9,
  spikeVolumeThreshold: 2.2,
  spikeOiThreshold: 1.8,
  refreshSeconds: 5
};

const timeframeDefinitions = [
  { key: "3m", label: "3 Minute" },
  { key: "15m", label: "15 Minute" },
  { key: "1h", label: "1 Hour" },
  { key: "1d", label: "1 Day" }
];

const baseStocks = [
  {
    symbol: "RELIANCE",
    sector: "Energy",
    priceChangePct: 3.8,
    oiChangePct: 9.4,
    volumeMultiple: 1.9,
    aboveWeeklyVWAP: true,
    bollingerTightest: true,
    breakoutDistancePct: 0.4,
    hvnBelowPrice: true,
    beta: 1.31,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 2986,
    previousDayHigh: 2968,
    vah: 2974,
    val: 2916,
    poc: 2944,
    volumeSpikeOnRetest: true,
    bidQty: 420000,
    askQty: 175000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: true,
    breakoutRetestHold: true,
    trendIntact: true,
    bullishEngulfingAtPoc: false,
    atr: 24,
    high: 2998,
    low: 2934,
    close: 2986
  },
  {
    symbol: "TATAMOTORS",
    sector: "Auto",
    priceChangePct: 2.7,
    oiChangePct: 6.6,
    volumeMultiple: 1.8,
    aboveWeeklyVWAP: true,
    bollingerTightest: false,
    breakoutDistancePct: 1.3,
    hvnBelowPrice: true,
    beta: 1.42,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 1062,
    previousDayHigh: 1054,
    vah: 1050,
    val: 1028,
    poc: 1041,
    volumeSpikeOnRetest: true,
    bidQty: 310000,
    askQty: 120000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: true,
    breakoutRetestHold: true,
    trendIntact: true,
    bullishEngulfingAtPoc: false,
    atr: 11,
    high: 1068,
    low: 1038,
    close: 1062
  },
  {
    symbol: "SUNPHARMA",
    sector: "Pharma",
    priceChangePct: 1.8,
    oiChangePct: 8.1,
    volumeMultiple: 1.4,
    aboveWeeklyVWAP: true,
    bollingerTightest: true,
    breakoutDistancePct: 0.6,
    hvnBelowPrice: true,
    beta: 1.24,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 1748,
    previousDayHigh: 1751,
    vah: 1740,
    val: 1714,
    poc: 1728,
    volumeSpikeOnRetest: false,
    bidQty: 260000,
    askQty: 162000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: false,
    breakoutRetestHold: false,
    trendIntact: true,
    bullishEngulfingAtPoc: true,
    atr: 16,
    high: 1756,
    low: 1720,
    close: 1748
  },
  {
    symbol: "HDFCBANK",
    sector: "Banking",
    priceChangePct: 2.4,
    oiChangePct: 5.8,
    volumeMultiple: 1.6,
    aboveWeeklyVWAP: true,
    bollingerTightest: true,
    breakoutDistancePct: 0.8,
    hvnBelowPrice: true,
    beta: 1.08,
    near52WeekHigh: false,
    outperformingNifty: true,
    currentPrice: 1686,
    previousDayHigh: 1678,
    vah: 1680,
    val: 1654,
    poc: 1668,
    volumeSpikeOnRetest: true,
    bidQty: 280000,
    askQty: 160000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: true,
    breakoutRetestHold: true,
    trendIntact: true,
    bullishEngulfingAtPoc: false,
    atr: 14,
    high: 1691,
    low: 1660,
    close: 1686
  },
  {
    symbol: "LT",
    sector: "Capital Goods",
    priceChangePct: 1.4,
    oiChangePct: 4.3,
    volumeMultiple: 1.2,
    aboveWeeklyVWAP: true,
    bollingerTightest: true,
    breakoutDistancePct: 0.5,
    hvnBelowPrice: true,
    beta: 1.34,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 3842,
    previousDayHigh: 3848,
    vah: 3835,
    val: 3788,
    poc: 3812,
    volumeSpikeOnRetest: false,
    bidQty: 210000,
    askQty: 155000,
    sellWallAbove: false,
    absorptionVisible: false,
    candleCloseAbovePreviousHigh: false,
    breakoutRetestHold: false,
    trendIntact: true,
    bullishEngulfingAtPoc: true,
    atr: 31,
    high: 3852,
    low: 3792,
    close: 3842
  },
  {
    symbol: "ADANIPORTS",
    sector: "Infra",
    priceChangePct: 4.2,
    oiChangePct: 10.8,
    volumeMultiple: 2.3,
    aboveWeeklyVWAP: true,
    bollingerTightest: true,
    breakoutDistancePct: 0.3,
    hvnBelowPrice: true,
    beta: 1.57,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 1544,
    previousDayHigh: 1532,
    vah: 1536,
    val: 1495,
    poc: 1518,
    volumeSpikeOnRetest: true,
    bidQty: 510000,
    askQty: 180000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: true,
    breakoutRetestHold: true,
    trendIntact: true,
    bullishEngulfingAtPoc: false,
    atr: 19,
    high: 1551,
    low: 1506,
    close: 1544
  }
];

baseStocks.push(
  {
    symbol: "SBIN",
    sector: "Banking",
    priceChangePct: 2.1,
    oiChangePct: 5.2,
    volumeMultiple: 1.7,
    aboveWeeklyVWAP: true,
    bollingerTightest: false,
    breakoutDistancePct: 1.2,
    hvnBelowPrice: false,
    beta: 1.28,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 862,
    previousDayHigh: 858,
    vah: 856,
    val: 842,
    poc: 849,
    volumeSpikeOnRetest: true,
    bidQty: 240000,
    askQty: 118000,
    sellWallAbove: true,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: true,
    breakoutRetestHold: true,
    trendIntact: true,
    bullishEngulfingAtPoc: false,
    atr: 8,
    high: 866,
    low: 846,
    close: 862
  },
  {
    symbol: "BAJFINANCE",
    sector: "NBFC",
    priceChangePct: 1.7,
    oiChangePct: 3.8,
    volumeMultiple: 1.3,
    aboveWeeklyVWAP: false,
    bollingerTightest: true,
    breakoutDistancePct: 0.7,
    hvnBelowPrice: true,
    beta: 1.38,
    near52WeekHigh: true,
    outperformingNifty: false,
    currentPrice: 7286,
    previousDayHigh: 7310,
    vah: 7268,
    val: 7192,
    poc: 7232,
    volumeSpikeOnRetest: false,
    bidQty: 170000,
    askQty: 112000,
    sellWallAbove: false,
    absorptionVisible: false,
    candleCloseAbovePreviousHigh: false,
    breakoutRetestHold: false,
    trendIntact: false,
    bullishEngulfingAtPoc: false,
    atr: 58,
    high: 7328,
    low: 7208,
    close: 7286
  },
  {
    symbol: "PERSISTENT",
    sector: "IT",
    priceChangePct: 3.4,
    oiChangePct: 7.2,
    volumeMultiple: 1.8,
    aboveWeeklyVWAP: true,
    bollingerTightest: true,
    breakoutDistancePct: 0.6,
    hvnBelowPrice: true,
    beta: 1.36,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 4210,
    previousDayHigh: 4194,
    vah: 4198,
    val: 4136,
    poc: 4172,
    volumeSpikeOnRetest: true,
    bidQty: 205000,
    askQty: 88000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: true,
    breakoutRetestHold: true,
    trendIntact: true,
    bullishEngulfingAtPoc: false,
    atr: 34,
    high: 4234,
    low: 4152,
    close: 4210
  },
  {
    symbol: "DIXON",
    sector: "Consumer Electronics",
    priceChangePct: 2.9,
    oiChangePct: 6.1,
    volumeMultiple: 1.7,
    aboveWeeklyVWAP: true,
    bollingerTightest: true,
    breakoutDistancePct: 0.9,
    hvnBelowPrice: true,
    beta: 1.48,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 12184,
    previousDayHigh: 12120,
    vah: 12110,
    val: 11930,
    poc: 12014,
    volumeSpikeOnRetest: true,
    bidQty: 122000,
    askQty: 52000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: true,
    breakoutRetestHold: true,
    trendIntact: true,
    bullishEngulfingAtPoc: false,
    atr: 96,
    high: 12226,
    low: 11966,
    close: 12184
  },
  {
    symbol: "MOTHERSON",
    sector: "Auto Ancillary",
    priceChangePct: 2.3,
    oiChangePct: 5.4,
    volumeMultiple: 1.6,
    aboveWeeklyVWAP: true,
    bollingerTightest: true,
    breakoutDistancePct: 0.8,
    hvnBelowPrice: true,
    beta: 1.29,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 214,
    previousDayHigh: 212,
    vah: 211.4,
    val: 206.8,
    poc: 209.6,
    volumeSpikeOnRetest: true,
    bidQty: 410000,
    askQty: 168000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: true,
    breakoutRetestHold: true,
    trendIntact: true,
    bullishEngulfingAtPoc: false,
    atr: 2.8,
    high: 215.2,
    low: 208.4,
    close: 214
  }
);

baseStocks.push(
  {
    symbol: "CHOLAFIN",
    sector: "NBFC",
    priceChangePct: 1.9,
    oiChangePct: 6.8,
    volumeMultiple: 1.5,
    aboveWeeklyVWAP: true,
    bollingerTightest: true,
    breakoutDistancePct: 0.4,
    hvnBelowPrice: true,
    beta: 1.33,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 1628,
    previousDayHigh: 1633,
    vah: 1620,
    val: 1592,
    poc: 1606,
    volumeSpikeOnRetest: false,
    bidQty: 176000,
    askQty: 92000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: false,
    breakoutRetestHold: false,
    trendIntact: true,
    bullishEngulfingAtPoc: true,
    atr: 15,
    high: 1638,
    low: 1599,
    close: 1628
  },
  {
    symbol: "INDHOTEL",
    sector: "Hospitality",
    priceChangePct: 2.6,
    oiChangePct: 7.5,
    volumeMultiple: 1.9,
    aboveWeeklyVWAP: true,
    bollingerTightest: false,
    breakoutDistancePct: 0.9,
    hvnBelowPrice: true,
    beta: 1.27,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 642,
    previousDayHigh: 638,
    vah: 637,
    val: 626,
    poc: 632,
    volumeSpikeOnRetest: true,
    bidQty: 282000,
    askQty: 121000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: true,
    breakoutRetestHold: true,
    trendIntact: true,
    bullishEngulfingAtPoc: false,
    atr: 6.2,
    high: 645,
    low: 629,
    close: 642
  },
  {
    symbol: "TORNTPHARM",
    sector: "Pharma",
    priceChangePct: 1.6,
    oiChangePct: 5.1,
    volumeMultiple: 1.2,
    aboveWeeklyVWAP: true,
    bollingerTightest: true,
    breakoutDistancePct: 0.5,
    hvnBelowPrice: true,
    beta: 1.22,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 2868,
    previousDayHigh: 2876,
    vah: 2860,
    val: 2826,
    poc: 2844,
    volumeSpikeOnRetest: false,
    bidQty: 128000,
    askQty: 71000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: false,
    breakoutRetestHold: false,
    trendIntact: true,
    bullishEngulfingAtPoc: true,
    atr: 22,
    high: 2884,
    low: 2836,
    close: 2868
  },
  {
    symbol: "MCX",
    sector: "Exchange",
    priceChangePct: 3.1,
    oiChangePct: 8.6,
    volumeMultiple: 2.1,
    aboveWeeklyVWAP: true,
    bollingerTightest: true,
    breakoutDistancePct: 0.2,
    hvnBelowPrice: true,
    beta: 1.41,
    near52WeekHigh: true,
    outperformingNifty: true,
    currentPrice: 4026,
    previousDayHigh: 4002,
    vah: 4008,
    val: 3944,
    poc: 3980,
    volumeSpikeOnRetest: true,
    bidQty: 196000,
    askQty: 76000,
    sellWallAbove: false,
    absorptionVisible: true,
    candleCloseAbovePreviousHigh: true,
    breakoutRetestHold: true,
    trendIntact: true,
    bullishEngulfingAtPoc: false,
    atr: 38,
    high: 4042,
    low: 3962,
    close: 4026
  }
);

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function symbolSeed(symbol) {
  return symbol.split("").reduce((sum, char, index) => sum + char.charCodeAt(0) * (index + 1), 0);
}

function round(value, decimals = 2) {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

function timeframeMultiplier(key) {
  return {
    "3m": 0.18,
    "15m": 0.38,
    "1h": 0.62,
    "1d": 1
  }[key];
}

function buildTimeframes(stock) {
  const seed = symbolSeed(stock.symbol);
  const baseVolume = stock.bidQty + stock.askQty;

  return timeframeDefinitions.reduce((accumulator, timeframe, index) => {
    const multiplier = timeframeMultiplier(timeframe.key);
    const drift = ((seed % (9 + index)) - 3) * 0.12;
    const priceChangePct = round(stock.priceChangePct * multiplier + drift, 2);
    const oiChangePct = round(stock.oiChangePct * multiplier + drift * 1.6, 2);
    const volumeMultiple = round(
      clamp(stock.volumeMultiple * (0.75 + multiplier * 0.65) + (seed % (7 + index)) * 0.04, 0.8, 4.5),
      2
    );
    const breakoutDistancePct = round(
      clamp(stock.breakoutDistancePct + (1 - multiplier) * 0.45 + ((seed % 5) - 2) * 0.05, 0.1, 2.4),
      2
    );
    const currentPrice = round(stock.currentPrice * (1 + priceChangePct / 100), 2);
    const prevClose = round(currentPrice / (1 + priceChangePct / 100), 2);
    const timeframeAtr = round(stock.atr * multiplier, 2);
    const volume = Math.round(baseVolume * multiplier * (0.9 + (seed % 11) * 0.01));

    accumulator[timeframe.key] = {
      timeframe: timeframe.key,
      priceChangePct,
      oiChangePct,
      volumeMultiple,
      breakoutDistancePct,
      currentPrice,
      prevClose,
      atr: timeframeAtr,
      volume,
      aboveVWAP: timeframe.key === "1d" ? stock.aboveWeeklyVWAP : currentPrice >= stock.poc,
      volumeSpikeOnRetest:
        timeframe.key === "1d"
          ? stock.volumeSpikeOnRetest
          : volumeMultiple >= 1.8 && breakoutDistancePct <= 1.2,
      candleConfirmation:
        timeframe.key === "3m"
          ? currentPrice >= stock.vah && volumeMultiple >= 1.7
          : timeframe.key === "15m"
            ? currentPrice >= stock.poc
            : timeframe.key === "1h"
              ? currentPrice >= stock.poc * 0.995
              : stock.candleCloseAbovePreviousHigh,
      bullishPattern:
        timeframe.key === "15m" || timeframe.key === "1h"
          ? stock.bullishEngulfingAtPoc || currentPrice >= stock.poc
          : stock.bullishEngulfingAtPoc,
      squeezeReady:
        stock.bollingerTightest && breakoutDistancePct <= 1.2,
      relativeStrengthReady:
        stock.beta > 1.2 && stock.outperformingNifty && priceChangePct > 0
    };

    return accumulator;
  }, {});
}

function enrichStocks(stocks) {
  return stocks.map((stock) => ({
    ...stock,
    timeframes: buildTimeframes(stock)
  }));
}

class LiveDataAdapter {
  constructor(name) {
    this.name = name;
  }

  async connect() {
    return { connected: true, message: `${this.name} adapter ready` };
  }

  async poll() {
    return [];
  }
}

class MockLiveAdapter extends LiveDataAdapter {
  constructor() {
    super("mock-live");
    this.tick = 0;
  }

  async poll(stocks) {
    this.tick += 1;

    return stocks.map((stock) => {
      const seed = symbolSeed(stock.symbol) + this.tick * 17;
      const pulse = ((seed % 9) - 4) * 0.22;
      const burst = this.tick % 5 === 0 && seed % 3 === 0 ? 1.6 : 0;
      const priceBump = pulse + burst;
      const volumeBump = clamp(1 + (seed % 7) * 0.16 + burst * 0.75, 1, 4.8);
      const oiBump = clamp(0.5 + (seed % 5) * 0.3 + burst * 0.5, 0.5, 4.5);
      const livePrice = round(stock.currentPrice * (1 + priceBump / 100), 2);
      const bidQty = Math.round(stock.bidQty * (1 + (seed % 4) * 0.1 + burst * 0.2));
      const askQty = Math.round(stock.askQty * (1 - (seed % 3) * 0.04 + (burst > 0 ? -0.1 : 0)));

      return {
        symbol: stock.symbol,
        livePrice,
        bidQty,
        askQty: Math.max(askQty, 1000),
        absorptionVisible: stock.absorptionVisible || burst > 0,
        sellWallAbove: burst > 0 ? false : stock.sellWallAbove,
        timeframeDeltas: {
          "3m": {
            priceChangePct: round(priceBump, 2),
            volumeMultiple: round(volumeBump, 2),
            oiImpulse: round(oiBump, 2)
          },
          "15m": {
            priceChangePct: round(priceBump * 0.8, 2),
            volumeMultiple: round(Math.max(1, volumeBump * 0.85), 2),
            oiImpulse: round(Math.max(0.5, oiBump * 0.9), 2)
          },
          "1h": {
            priceChangePct: round(priceBump * 0.55, 2),
            volumeMultiple: round(Math.max(1, volumeBump * 0.72), 2),
            oiImpulse: round(Math.max(0.4, oiBump * 0.75), 2)
          }
        },
        timestamp: new Date().toLocaleTimeString("en-IN", { hour12: false })
      };
    });
  }
}

class ManualWebhookAdapter extends LiveDataAdapter {
  constructor() {
    super("manual-webhook");
  }

  async connect() {
    return {
      connected: true,
      message: "Waiting for broker webhooks or manual snapshot injection"
    };
  }
}

const adapterRegistry = new Map();

function registerAdapter(key, adapterFactory) {
  adapterRegistry.set(key, adapterFactory);
}

registerAdapter("mock-live", () => new MockLiveAdapter());
registerAdapter("manual-webhook", () => new ManualWebhookAdapter());

const state = {
  universe: enrichStocks(baseStocks),
  activeTimeframes: new Set(["3m", "15m", "1h", "1d"]),
  providerKey: "mock-live",
  provider: null,
  liveMode: false,
  timerId: null,
  lastUpdatedAt: null,
  previousSnapshots: new Map(),
  spikeAlerts: [],
  latestResults: []
};

const inputs = {
  priceChangeThreshold: document.getElementById("priceChangeThreshold"),
  oiThreshold: document.getElementById("oiThreshold"),
  volumeThreshold: document.getElementById("volumeThreshold"),
  betaThreshold: document.getElementById("betaThreshold"),
  breakoutZoneThreshold: document.getElementById("breakoutZoneThreshold"),
  bidAskThreshold: document.getElementById("bidAskThreshold"),
  spikePriceThreshold: document.getElementById("spikePriceThreshold"),
  spikeVolumeThreshold: document.getElementById("spikeVolumeThreshold"),
  spikeOiThreshold: document.getElementById("spikeOiThreshold"),
  refreshSeconds: document.getElementById("refreshSeconds")
};

const selectedCount = document.getElementById("selectedCount");
const actionableCount = document.getElementById("actionableCount");
const watchlistCount = document.getElementById("watchlistCount");
const universeCount = document.getElementById("universeCount");
const liveCount = document.getElementById("liveCount");
const tradeCards = document.getElementById("tradeCards");
const scannerTableBody = document.getElementById("scannerTableBody");
const executionPrompt = document.getElementById("executionPrompt");
const resetButton = document.getElementById("resetButton");
const copyPromptButton = document.getElementById("copyPromptButton");
const timeframeCheckboxes = Array.from(document.querySelectorAll("[data-timeframe]"));
const spikeFeed = document.getElementById("spikeFeed");
const adapterStatus = document.getElementById("adapterStatus");
const activeTimeframesLabel = document.getElementById("activeTimeframesLabel");
const lastUpdatedLabel = document.getElementById("lastUpdatedLabel");
const providerSelect = document.getElementById("providerSelect");
const connectButton = document.getElementById("connectButton");
const startLiveButton = document.getElementById("startLiveButton");
const stopLiveButton = document.getElementById("stopLiveButton");

function getSettings() {
  return Object.fromEntries(
    Object.entries(inputs).map(([key, element]) => [key, Number(element.value)])
  );
}

function getActiveTimeframes() {
  return timeframeCheckboxes.filter((input) => input.checked).map((input) => input.dataset.timeframe);
}

function pivotLevels(stock) {
  const pivot = (stock.high + stock.low + stock.close) / 3;
  return {
    pivot,
    r1: 2 * pivot - stock.low,
    r2: pivot + (stock.high - stock.low)
  };
}

function summarizeTimeframeAlignment(stock, activeTimeframes, settings) {
  return activeTimeframes.map((key) => {
    const metrics = stock.timeframes[key];
    const aligned =
      metrics.priceChangePct > (key === "1d" ? settings.priceChangeThreshold : 0.15) &&
      metrics.volumeMultiple > 1.2 &&
      metrics.currentPrice >= stock.poc * 0.995;

    return {
      key,
      aligned,
      spikeReady:
        metrics.priceChangePct >= settings.spikePriceThreshold ||
        metrics.volumeMultiple >= settings.spikeVolumeThreshold
    };
  });
}

function analyzeStock(stock, settings, activeTimeframes) {
  const daily = stock.timeframes["1d"];
  const intraday = stock.timeframes["15m"];
  const entryFrame = stock.timeframes["3m"];
  const trendFrame = stock.timeframes["1h"];

  const longBuildup =
    daily.priceChangePct > settings.priceChangeThreshold &&
    daily.oiChangePct > settings.oiThreshold &&
    daily.volumeMultiple > settings.volumeThreshold &&
    stock.aboveWeeklyVWAP;

  const squeeze =
    stock.bollingerTightest &&
    intraday.breakoutDistancePct <= settings.breakoutZoneThreshold &&
    stock.hvnBelowPrice;

  const relativeStrength =
    stock.beta > settings.betaThreshold &&
    stock.near52WeekHigh &&
    stock.outperformingNifty &&
    trendFrame.priceChangePct > 0;

  const timeframeAlignment = summarizeTimeframeAlignment(stock, activeTimeframes, settings);
  const alignedCount = timeframeAlignment.filter((frame) => frame.aligned).length;
  const scannerCount = [longBuildup, squeeze, relativeStrength].filter(Boolean).length;

  const volumeProfileReady =
    intraday.currentPrice >= stock.vah &&
    intraday.volumeSpikeOnRetest &&
    stock.breakoutRetestHold;

  const bidAskRatio = stock.askQty === 0 ? stock.bidQty : stock.bidQty / stock.askQty;
  const orderDepthConfirmed =
    bidAskRatio >= settings.bidAskThreshold &&
    !stock.sellWallAbove &&
    stock.absorptionVisible;

  const retestEntry =
    entryFrame.candleConfirmation &&
    stock.candleCloseAbovePreviousHigh &&
    stock.breakoutRetestHold &&
    orderDepthConfirmed &&
    volumeProfileReady;

  const pocBounce =
    trendFrame.currentPrice >= stock.poc * 0.995 &&
    stock.trendIntact &&
    intraday.bullishPattern &&
    orderDepthConfirmed;

  const multiTimeframeQualified = alignedCount >= Math.max(2, Math.ceil(activeTimeframes.length / 2));
  const qualifies = scannerCount >= 2 && multiTimeframeQualified;
  const actionable = qualifies && (retestEntry || pocBounce);
  const entryType = retestEntry ? "Breakout Retest" : pocBounce ? "POC Bounce" : "Watchlist";
  const entry = retestEntry ? stock.vah : pocBounce ? stock.poc : stock.currentPrice;
  const stopLoss = entry - 1.5 * daily.atr;
  const { pivot, r1, r2 } = pivotLevels(stock);
  const status = actionable ? "Actionable" : qualifies ? "Watchlist" : "Rejected";

  const score =
    scannerCount * 35 +
    alignedCount * 8 +
    (orderDepthConfirmed ? 18 : 0) +
    (volumeProfileReady ? 15 : 0) +
    (retestEntry ? 15 : 0) +
    (pocBounce ? 10 : 0);

  return {
    ...stock,
    longBuildup,
    squeeze,
    relativeStrength,
    scannerCount,
    timeframeAlignment,
    alignedCount,
    multiTimeframeQualified,
    volumeProfileReady,
    bidAskRatio,
    orderDepthConfirmed,
    retestEntry,
    pocBounce,
    entryType,
    entry,
    stopLoss,
    pivot,
    r1,
    r2,
    actionable,
    qualifies,
    status,
    score
  };
}

function detectSpikes(stocks, settings, activeTimeframes) {
  const alerts = [];

  stocks.forEach((stock) => {
    const previous = state.previousSnapshots.get(stock.symbol);
    const current = {};

    activeTimeframes.forEach((key) => {
      const metrics = stock.timeframes[key];
      current[key] = {
        priceChangePct: metrics.priceChangePct,
        volumeMultiple: metrics.volumeMultiple,
        oiChangePct: metrics.oiChangePct ?? 0
      };

      if (!previous || !previous[key]) {
        return;
      }

      const prior = previous[key];
      const priceImpulse = metrics.priceChangePct - prior.priceChangePct;
      const volumeImpulse = metrics.volumeMultiple - prior.volumeMultiple;
      const oiImpulse = (metrics.oiChangePct ?? 0) - (prior.oiChangePct ?? 0);

      if (
        priceImpulse >= settings.spikePriceThreshold ||
        volumeImpulse >= settings.spikeVolumeThreshold ||
        oiImpulse >= settings.spikeOiThreshold
      ) {
        alerts.push({
          symbol: stock.symbol,
          timeframe: key,
          priceImpulse: round(priceImpulse, 2),
          volumeImpulse: round(volumeImpulse, 2),
          oiImpulse: round(oiImpulse, 2),
          timestamp: stock.lastTickTimestamp || new Date().toLocaleTimeString("en-IN", { hour12: false })
        });
      }
    });

    state.previousSnapshots.set(stock.symbol, current);
  });

  state.spikeAlerts = [...alerts, ...state.spikeAlerts].slice(0, 12);
}

function formatPrice(value) {
  return `Rs ${value.toFixed(2)}`;
}

function formatPercent(value) {
  return `${value.toFixed(1)}%`;
}

function boolChip(value) {
  if (value === true) {
    return '<span class="chip yes">Yes</span>';
  }

  if (value === false) {
    return '<span class="chip no">No</span>';
  }

  return '<span class="chip partial">Watch</span>';
}

function timeframeChips(alignment) {
  return alignment
    .map(
      (frame) => `<span class="chip ${frame.aligned ? "yes" : frame.spikeReady ? "partial" : "no"}">${frame.key}</span>`
    )
    .join("");
}

function renderPrompt(settings, activeTimeframes) {
  executionPrompt.value = [
    "Act as a professional F&O trader.",
    "",
    `Step 1: Scan all NSE F&O stocks across ${activeTimeframes.join(", ")} timeframes.`,
    `- Long buildup criteria on 1D (Price > ${settings.priceChangeThreshold}%, OI > ${settings.oiThreshold}%, Volume > ${settings.volumeThreshold}x avg, above weekly VWAP)`,
    `- Squeeze setup on 15m / 1h (HVN below price, breakout zone within ${settings.breakoutZoneThreshold}%)`,
    `- Relative strength on 1D with intraday trend alignment (Beta > ${settings.betaThreshold}, near 52W high, outperforming Nifty 50)`,
    "",
    "Step 2: Select top 5 stocks meeting at least 2 core scanners and multi-timeframe alignment.",
    "",
    "Step 3: For each stock:",
    "- Identify VAH, VAL, POC",
    "- Check whether 3m and 15m are confirming the 1h and 1d direction",
    "",
    "Step 4: Confirm entry using:",
    `- Order depth (Bid > Ask ${settings.bidAskThreshold}:1)`,
    "- Volume spike and retest behavior",
    "- 3-minute confirmation for timing, 15-minute candle structure for follow-through",
    "",
    "Step 5: Monitor spike engine:",
    `- Price impulse >= ${settings.spikePriceThreshold}%`,
    `- Volume impulse >= ${settings.spikeVolumeThreshold}x`,
    `- OI impulse >= ${settings.spikeOiThreshold}%`,
    "",
    "Step 6: Provide entry, stop loss (1.5 ATR), targets (R1, R2), and trade type.",
    "",
    "Only return high probability trades."
  ].join("\n");
}

function renderSpikeFeed() {
  if (state.spikeAlerts.length === 0) {
    spikeFeed.innerHTML = `
      <article class="spike-item">
        <strong>No live spike alerts yet</strong>
        <p>Connect an adapter and start live mode to watch 3m, 15m, 1h, and 1d impulses accumulate.</p>
      </article>
    `;
    liveCount.textContent = "0";
    return;
  }

  liveCount.textContent = String(state.spikeAlerts.length);
  spikeFeed.innerHTML = state.spikeAlerts
    .map(
      (alert) => `
        <article class="spike-item">
          <div class="spike-head">
            <strong>${alert.symbol}</strong>
            <span class="chip yes">${alert.timeframe}</span>
          </div>
          <p>Price impulse ${formatPercent(alert.priceImpulse)} | Volume impulse ${alert.volumeImpulse.toFixed(2)}x | OI impulse ${formatPercent(alert.oiImpulse)}</p>
          <small>${alert.timestamp}</small>
        </article>
      `
    )
    .join("");
}

function render(results, activeTimeframes) {
  const sorted = [...results].sort((a, b) => b.score - a.score);
  const topFive = sorted.filter((item) => item.qualifies).slice(0, 5);

  selectedCount.textContent = String(topFive.length);
  actionableCount.textContent = String(topFive.filter((item) => item.actionable).length);
  watchlistCount.textContent = String(topFive.filter((item) => !item.actionable).length);
  universeCount.textContent = String(results.length);
  activeTimeframesLabel.textContent = activeTimeframes.join(", ");
  lastUpdatedLabel.value = state.lastUpdatedAt || "Static snapshot";

  tradeCards.innerHTML = topFive
    .map(
      (stock) => `
        <article class="trade-card">
          <header>
            <div class="symbol-block">
              <h3>${stock.symbol}</h3>
              <p>${stock.sector} | ${stock.entryType}</p>
            </div>
            <span class="status-pill ${stock.actionable ? "actionable" : "watchlist"}">${stock.status}</span>
          </header>

          <div class="scanner-strip">
            <span class="chip ${stock.longBuildup ? "yes" : "no"}">Long Buildup</span>
            <span class="chip ${stock.squeeze ? "yes" : "no"}">Squeeze</span>
            <span class="chip ${stock.relativeStrength ? "yes" : "no"}">Rel Strength</span>
          </div>

          <div class="scanner-strip">
            ${timeframeChips(stock.timeframeAlignment)}
          </div>

          <div class="metrics">
            <div class="metric">
              <span>Entry</span>
              <strong>${formatPrice(stock.entry)}</strong>
            </div>
            <div class="metric">
              <span>Stop Loss</span>
              <strong>${formatPrice(stock.stopLoss)}</strong>
            </div>
            <div class="metric">
              <span>Target 1 (R1)</span>
              <strong>${formatPrice(stock.r1)}</strong>
            </div>
            <div class="metric">
              <span>Target 2 (R2)</span>
              <strong>${formatPrice(stock.r2)}</strong>
            </div>
            <div class="metric">
              <span>POC / VAH / VAL</span>
              <strong>${formatPrice(stock.poc)} / ${formatPrice(stock.vah)} / ${formatPrice(stock.val)}</strong>
            </div>
            <div class="metric">
              <span>Bid:Ask</span>
              <strong>${stock.bidAskRatio.toFixed(2)} : 1</strong>
            </div>
          </div>

          <div class="strategy-note">
            <div class="micro-copy">
              Scanner alignment: ${stock.scannerCount}/3 and timeframe alignment ${stock.alignedCount}/${activeTimeframes.length}.
              1D price change ${formatPercent(stock.timeframes["1d"].priceChangePct)}, 15m volume ${stock.timeframes["15m"].volumeMultiple.toFixed(1)}x.
            </div>
            <div class="metric-note">
              Use 3m timing, 15m structure confirmation, 1h trend bias, and 1d context. Book 50% at R1 and trail the rest on 9 EMA of the 5-minute execution chart if you use it manually.
            </div>
          </div>
        </article>
      `
    )
    .join("");

  if (topFive.length === 0) {
    tradeCards.innerHTML = `
      <article class="trade-card">
        <h3>No candidates</h3>
        <p class="micro-copy">The current thresholds or timeframe alignment are filtering out the sample universe. Relax one or two controls to surface setups.</p>
      </article>
    `;
  }

  scannerTableBody.innerHTML = sorted
    .map(
      (stock) => `
        <tr>
          <td><strong>${stock.symbol}</strong></td>
          <td>${boolChip(stock.longBuildup)}</td>
          <td>${boolChip(stock.squeeze)}</td>
          <td>${boolChip(stock.relativeStrength)}</td>
          <td>${stock.scannerCount}/3</td>
          <td>${stock.alignedCount}/${activeTimeframes.length}</td>
          <td>${boolChip(stock.orderDepthConfirmed)}</td>
          <td><span class="status-pill ${stock.actionable ? "actionable" : stock.qualifies ? "watchlist" : "reject"}">${stock.status}</span></td>
        </tr>
      `
    )
    .join("");

  renderSpikeFeed();
}

function runScanner() {
  const settings = getSettings();
  const activeTimeframes = getActiveTimeframes();

  if (activeTimeframes.length === 0) {
    timeframeCheckboxes.find((input) => input.dataset.timeframe === "1d").checked = true;
    return runScanner();
  }

  state.activeTimeframes = new Set(activeTimeframes);
  detectSpikes(state.universe, settings, activeTimeframes);
  const analyzed = state.universe.map((stock) => analyzeStock(stock, settings, activeTimeframes));
  state.latestResults = analyzed;
  renderPrompt(settings, activeTimeframes);
  render(analyzed, activeTimeframes);
}

function applyLiveUpdate(update) {
  state.universe = state.universe.map((stock) => {
    if (stock.symbol !== update.symbol) {
      return stock;
    }

    const next = {
      ...stock,
      currentPrice: update.livePrice,
      bidQty: update.bidQty,
      askQty: update.askQty,
      absorptionVisible: update.absorptionVisible,
      sellWallAbove: update.sellWallAbove,
      lastTickTimestamp: update.timestamp
    };

    const timeframes = { ...stock.timeframes };

    Object.entries(update.timeframeDeltas).forEach(([key, delta]) => {
      const previous = stock.timeframes[key];

      timeframes[key] = {
        ...previous,
        priceChangePct: round(previous.priceChangePct + delta.priceChangePct, 2),
        oiChangePct: round((previous.oiChangePct ?? 0) + delta.oiImpulse, 2),
        volumeMultiple: round(Math.max(1, previous.volumeMultiple + delta.volumeMultiple - 1), 2),
        currentPrice: update.livePrice,
        volumeSpikeOnRetest: previous.volumeSpikeOnRetest || delta.volumeMultiple >= 2
      };
    });

    timeframes["1d"] = {
      ...stock.timeframes["1d"],
      currentPrice: update.livePrice
    };

    return {
      ...next,
      timeframes
    };
  });
}

async function connectProvider() {
  const providerFactory = adapterRegistry.get(providerSelect.value);

  if (!providerFactory) {
    adapterStatus.textContent = "Adapter not found";
    return;
  }

  state.providerKey = providerSelect.value;
  state.provider = providerFactory();
  const response = await state.provider.connect();
  adapterStatus.textContent = response.message;
}

async function tickLiveMode() {
  if (!state.provider) {
    await connectProvider();
  }

  const updates = await state.provider.poll(state.universe);
  updates.forEach(applyLiveUpdate);
  state.lastUpdatedAt = new Date().toLocaleTimeString("en-IN", { hour12: false });
  adapterStatus.textContent = `Live updates via ${state.providerKey}`;
  runScanner();
}

function stopLiveMode() {
  if (state.timerId) {
    clearInterval(state.timerId);
    state.timerId = null;
  }

  state.liveMode = false;
  adapterStatus.textContent = `Live mode paused on ${state.providerKey}`;
}

async function startLiveMode() {
  stopLiveMode();
  await connectProvider();
  state.liveMode = true;
  await tickLiveMode();
  state.timerId = setInterval(tickLiveMode, getSettings().refreshSeconds * 1000);
}

Object.values(inputs).forEach((input) => {
  input.addEventListener("input", () => {
    if (input === inputs.refreshSeconds && state.liveMode) {
      startLiveMode();
      return;
    }

    runScanner();
  });
});

timeframeCheckboxes.forEach((checkbox) => {
  checkbox.addEventListener("change", runScanner);
});

providerSelect.addEventListener("change", connectProvider);
connectButton.addEventListener("click", connectProvider);
startLiveButton.addEventListener("click", startLiveMode);
stopLiveButton.addEventListener("click", stopLiveMode);

resetButton.addEventListener("click", () => {
  Object.entries(defaultSettings).forEach(([key, value]) => {
    inputs[key].value = value;
  });

  timeframeCheckboxes.forEach((checkbox) => {
    checkbox.checked = true;
  });

  stopLiveMode();
  state.previousSnapshots.clear();
  state.spikeAlerts = [];
  runScanner();
});

copyPromptButton.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(executionPrompt.value);
    copyPromptButton.textContent = "Copied";
    setTimeout(() => {
      copyPromptButton.textContent = "Copy Prompt";
    }, 1200);
  } catch (error) {
    copyPromptButton.textContent = "Copy Failed";
    setTimeout(() => {
      copyPromptButton.textContent = "Copy Prompt";
    }, 1200);
  }
});

connectProvider();
runScanner();

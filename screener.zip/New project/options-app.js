const ovDefaults = {
  oiThreshold: 100000,
  volumeThreshold: 25000,
  highIvThreshold: 50,
  lowIvThreshold: 20,
  highPcrThreshold: 1,
  lowPcrThreshold: 0.7,
  gammaSpikeThreshold: 20,
  flowRatioThreshold: 1.4
};

const ovUniverse = [
  {
    symbol: "RELIANCE",
    sector: "Energy",
    stochasticRsi: 0.86,
    bollingerBreakout: true,
    ichimokuBullish: true,
    volumeProfileSupport: true,
    iv: 54,
    hv: 32,
    ivTrend: "expanding",
    pcr: 0.68,
    callPremiumBought3d: 182,
    putPremiumSold3d: 126,
    buySellFlowRatio: 1.9,
    gammaExposureSpikePct: 28,
    absoluteGamma: "high",
    deltaShift: 17,
    vegaShift: 14,
    totalOptionsOi: 182000,
    avgOptionsVolume3d: 64000
  },
  {
    symbol: "HDFCBANK",
    sector: "Banking",
    stochasticRsi: 0.52,
    bollingerBreakout: false,
    ichimokuBullish: true,
    volumeProfileSupport: true,
    iv: 24,
    hv: 31,
    ivTrend: "collapsing",
    pcr: 1.12,
    callPremiumBought3d: 52,
    putPremiumSold3d: 84,
    buySellFlowRatio: 1.05,
    gammaExposureSpikePct: 12,
    absoluteGamma: "medium",
    deltaShift: 7,
    vegaShift: 5,
    totalOptionsOi: 246000,
    avgOptionsVolume3d: 71000
  },
  {
    symbol: "TATAMOTORS",
    sector: "Auto",
    stochasticRsi: 0.79,
    bollingerBreakout: true,
    ichimokuBullish: true,
    volumeProfileSupport: true,
    iv: 48,
    hv: 29,
    ivTrend: "expanding",
    pcr: 0.74,
    callPremiumBought3d: 118,
    putPremiumSold3d: 93,
    buySellFlowRatio: 1.55,
    gammaExposureSpikePct: 24,
    absoluteGamma: "high",
    deltaShift: 12,
    vegaShift: 11,
    totalOptionsOi: 224000,
    avgOptionsVolume3d: 84000
  },
  {
    symbol: "BAJFINANCE",
    sector: "NBFC",
    stochasticRsi: 0.34,
    bollingerBreakout: false,
    ichimokuBullish: false,
    volumeProfileSupport: true,
    iv: 57,
    hv: 36,
    ivTrend: "collapsing",
    pcr: 1.18,
    callPremiumBought3d: 44,
    putPremiumSold3d: 102,
    buySellFlowRatio: 0.92,
    gammaExposureSpikePct: 21,
    absoluteGamma: "high",
    deltaShift: -9,
    vegaShift: -12,
    totalOptionsOi: 168000,
    avgOptionsVolume3d: 43000
  },
  {
    symbol: "SBIN",
    sector: "Banking",
    stochasticRsi: 0.61,
    bollingerBreakout: false,
    ichimokuBullish: true,
    volumeProfileSupport: false,
    iv: 27,
    hv: 22,
    ivTrend: "stable",
    pcr: 1.06,
    callPremiumBought3d: 48,
    putPremiumSold3d: 78,
    buySellFlowRatio: 1.18,
    gammaExposureSpikePct: 16,
    absoluteGamma: "medium",
    deltaShift: 4,
    vegaShift: 3,
    totalOptionsOi: 302000,
    avgOptionsVolume3d: 93000
  },
  {
    symbol: "ADANIPORTS",
    sector: "Infra",
    stochasticRsi: 0.88,
    bollingerBreakout: true,
    ichimokuBullish: true,
    volumeProfileSupport: true,
    iv: 61,
    hv: 34,
    ivTrend: "expanding",
    pcr: 0.64,
    callPremiumBought3d: 136,
    putPremiumSold3d: 98,
    buySellFlowRatio: 1.82,
    gammaExposureSpikePct: 33,
    absoluteGamma: "high",
    deltaShift: 19,
    vegaShift: 16,
    totalOptionsOi: 192000,
    avgOptionsVolume3d: 52000
  },
  {
    symbol: "SUNPHARMA",
    sector: "Pharma",
    stochasticRsi: 0.49,
    bollingerBreakout: false,
    ichimokuBullish: true,
    volumeProfileSupport: true,
    iv: 22,
    hv: 29,
    ivTrend: "collapsing",
    pcr: 1.08,
    callPremiumBought3d: 29,
    putPremiumSold3d: 61,
    buySellFlowRatio: 0.98,
    gammaExposureSpikePct: 11,
    absoluteGamma: "medium",
    deltaShift: 2,
    vegaShift: -4,
    totalOptionsOi: 126000,
    avgOptionsVolume3d: 28000
  },
  {
    symbol: "MCX",
    sector: "Exchange",
    stochasticRsi: 0.73,
    bollingerBreakout: true,
    ichimokuBullish: true,
    volumeProfileSupport: true,
    iv: 19,
    hv: 17,
    ivTrend: "stable",
    pcr: 0.62,
    callPremiumBought3d: 94,
    putPremiumSold3d: 55,
    buySellFlowRatio: 1.66,
    gammaExposureSpikePct: 26,
    absoluteGamma: "high",
    deltaShift: 14,
    vegaShift: 9,
    totalOptionsOi: 108000,
    avgOptionsVolume3d: 26000
  }
];

const ovInputs = {
  oiThreshold: document.getElementById("ovOiThreshold"),
  volumeThreshold: document.getElementById("ovVolumeThreshold"),
  highIvThreshold: document.getElementById("ovHighIvThreshold"),
  lowIvThreshold: document.getElementById("ovLowIvThreshold"),
  highPcrThreshold: document.getElementById("ovHighPcrThreshold"),
  lowPcrThreshold: document.getElementById("ovLowPcrThreshold"),
  gammaSpikeThreshold: document.getElementById("ovGammaSpikeThreshold"),
  flowRatioThreshold: document.getElementById("ovFlowRatioThreshold")
};

const ovSelectedCount = document.getElementById("ovSelectedCount");
const ovShortVolCount = document.getElementById("ovShortVolCount");
const ovBreakoutCount = document.getElementById("ovBreakoutCount");
const ovNeutralCount = document.getElementById("ovNeutralCount");
const ovCards = document.getElementById("ovCards");
const ovTableBody = document.getElementById("ovTableBody");
const ovExecutionPrompt = document.getElementById("ovExecutionPrompt");
const ovResetButton = document.getElementById("ovResetButton");
const ovCopyPromptButton = document.getElementById("ovCopyPromptButton");

function ovGetSettings() {
  return Object.fromEntries(
    Object.entries(ovInputs).map(([key, element]) => [key, Number(element.value)])
  );
}

function ovFormatPercent(value) {
  return `${value.toFixed(1)}%`;
}

function ovBoolChip(value) {
  return `<span class="chip ${value ? "yes" : "no"}">${value ? "Yes" : "No"}</span>`;
}

function analyzeOvStock(stock, settings) {
  const technicalPass =
    stock.stochasticRsi >= 0.2 &&
    stock.stochasticRsi <= 0.9 &&
    (stock.bollingerBreakout || stock.ichimokuBullish) &&
    stock.volumeProfileSupport;

  const highIvShortVol = stock.iv >= settings.highIvThreshold && stock.iv > stock.hv;
  const lowIvLongGamma = stock.iv <= settings.lowIvThreshold;
  const ivCollapseMeanReversion = stock.ivTrend === "collapsing" && stock.iv < stock.hv;

  const bearishFear = stock.pcr >= settings.highPcrThreshold;
  const bullishBias = stock.pcr <= settings.lowPcrThreshold;

  const flowBullish =
    stock.callPremiumBought3d > stock.putPremiumSold3d &&
    stock.buySellFlowRatio >= settings.flowRatioThreshold;

  const flowNeutralToShortVol =
    stock.putPremiumSold3d >= stock.callPremiumBought3d &&
    stock.buySellFlowRatio >= 0.9;

  const gammaSpike =
    stock.gammaExposureSpikePct >= settings.gammaSpikeThreshold &&
    stock.absoluteGamma === "high";

  const liquidityPass =
    stock.totalOptionsOi >= settings.oiThreshold &&
    stock.avgOptionsVolume3d >= settings.volumeThreshold;

  let setup = "Watch";

  if (liquidityPass && highIvShortVol && ivCollapseMeanReversion && bearishFear) {
    setup = "Iron Condor / Mean Reversion";
  } else if (liquidityPass && highIvShortVol && (flowNeutralToShortVol || gammaSpike)) {
    setup = "Credit Spread / Short Gamma";
  } else if (liquidityPass && lowIvLongGamma && (stock.bollingerBreakout || gammaSpike)) {
    setup = "Long Gamma / Strangle";
  } else if (liquidityPass && technicalPass && flowBullish && bullishBias) {
    setup = "Bullish Breakout";
  }

  const matchedCount = [
    technicalPass,
    liquidityPass,
    highIvShortVol || lowIvLongGamma || ivCollapseMeanReversion,
    bullishBias || bearishFear,
    flowBullish || flowNeutralToShortVol,
    gammaSpike
  ].filter(Boolean).length;

  const qualifies = matchedCount >= 4 && setup !== "Watch";

  return {
    ...stock,
    technicalPass,
    highIvShortVol,
    lowIvLongGamma,
    ivCollapseMeanReversion,
    bearishFear,
    bullishBias,
    flowBullish,
    flowNeutralToShortVol,
    gammaSpike,
    liquidityPass,
    matchedCount,
    qualifies,
    setup,
    score:
      matchedCount * 20 +
      (highIvShortVol ? 12 : 0) +
      (ivCollapseMeanReversion ? 10 : 0) +
      (gammaSpike ? 10 : 0) +
      (flowBullish ? 8 : 0)
  };
}

function renderOvPrompt(settings) {
  ovExecutionPrompt.value = [
    "Scan NSE F&O names for options strategies.",
    "",
    "- Technical stack: stochastic RSI, Bollinger breakout, Ichimoku cloud, volume profile",
    `- Liquidity: total options OI >= ${settings.oiThreshold} and average options volume >= ${settings.volumeThreshold}`,
    `- High IV focus: IV >= ${settings.highIvThreshold}% for short-vol / credit spreads`,
    `- Low IV focus: IV <= ${settings.lowIvThreshold}% for long-gamma / breakout setups`,
    "- IV collapsing below HV: mean reversion / iron condor watchlist",
    `- PCR > ${settings.highPcrThreshold}: hedging / fear bias`,
    `- PCR < ${settings.lowPcrThreshold}: bullish sentiment`,
    `- Gamma exposure spike >= ${settings.gammaSpikeThreshold}%`,
    `- Buy-side vs sell-side options flow ratio >= ${settings.flowRatioThreshold}`,
    "",
    "Return only high-conviction setups with setup type and reason."
  ].join("\n");
}

function renderOv(results) {
  const sorted = [...results].sort((a, b) => b.score - a.score);
  const qualified = sorted.filter((stock) => stock.qualifies);

  ovSelectedCount.textContent = String(qualified.length);
  ovShortVolCount.textContent = String(
    qualified.filter((stock) => stock.setup.includes("Credit") || stock.setup.includes("Short") || stock.setup.includes("Iron")).length
  );
  ovBreakoutCount.textContent = String(
    qualified.filter((stock) => stock.setup.includes("Breakout") || stock.setup.includes("Long Gamma")).length
  );
  ovNeutralCount.textContent = String(
    qualified.filter((stock) => stock.setup.includes("Iron Condor") || stock.setup.includes("Mean Reversion")).length
  );

  ovCards.innerHTML = qualified.slice(0, 6).map((stock) => `
    <article class="trade-card">
      <header>
        <div class="symbol-block">
          <h3>${stock.symbol}</h3>
          <p>${stock.sector} | ${stock.setup}</p>
        </div>
        <span class="status-pill ${stock.qualifies ? "actionable" : "watchlist"}">${stock.matchedCount} filters</span>
      </header>

      <div class="scanner-strip">
        <span class="chip ${stock.technicalPass ? "yes" : "no"}">Technical</span>
        <span class="chip ${(stock.highIvShortVol || stock.lowIvLongGamma || stock.ivCollapseMeanReversion) ? "yes" : "no"}">IV/HV</span>
        <span class="chip ${(stock.bullishBias || stock.bearishFear) ? "yes" : "no"}">PCR</span>
        <span class="chip ${(stock.flowBullish || stock.flowNeutralToShortVol) ? "yes" : "no"}">Flow</span>
        <span class="chip ${stock.gammaSpike ? "yes" : "no"}">Gamma</span>
      </div>

      <div class="metrics">
        <div class="metric">
          <span>IV / HV</span>
          <strong>${ovFormatPercent(stock.iv)} / ${ovFormatPercent(stock.hv)}</strong>
        </div>
        <div class="metric">
          <span>PCR</span>
          <strong>${stock.pcr.toFixed(2)}</strong>
        </div>
        <div class="metric">
          <span>Total OI</span>
          <strong>${stock.totalOptionsOi.toLocaleString()}</strong>
        </div>
        <div class="metric">
          <span>Avg Vol 3D</span>
          <strong>${stock.avgOptionsVolume3d.toLocaleString()}</strong>
        </div>
        <div class="metric">
          <span>Flow Ratio</span>
          <strong>${stock.buySellFlowRatio.toFixed(2)}</strong>
        </div>
        <div class="metric">
          <span>Gamma Spike</span>
          <strong>${ovFormatPercent(stock.gammaExposureSpikePct)}</strong>
        </div>
      </div>

      <div class="strategy-note">
        Stoch RSI ${stock.stochasticRsi.toFixed(2)}, Bollinger ${stock.bollingerBreakout ? "breakout" : "inside band"},
        Ichimoku ${stock.ichimokuBullish ? "above cloud" : "below cloud"}, IV trend ${stock.ivTrend}.
      </div>
    </article>
  `).join("");

  if (qualified.length === 0) {
    ovCards.innerHTML = `
      <article class="trade-card">
        <h3>No qualified options setups</h3>
        <p class="micro-copy">Relax IV, OI, volume, or gamma thresholds to surface more opportunities.</p>
      </article>
    `;
  }

  ovTableBody.innerHTML = sorted.map((stock) => `
    <tr>
      <td><strong>${stock.symbol}</strong></td>
      <td>${ovBoolChip(stock.technicalPass)}</td>
      <td>${ovBoolChip(stock.highIvShortVol || stock.lowIvLongGamma || stock.ivCollapseMeanReversion)}</td>
      <td>${ovBoolChip(stock.bullishBias || stock.bearishFear)}</td>
      <td>${ovBoolChip(stock.flowBullish || stock.flowNeutralToShortVol)}</td>
      <td>${ovBoolChip(stock.gammaSpike)}</td>
      <td><span class="status-pill ${stock.qualifies ? "actionable" : "watchlist"}">${stock.setup}</span></td>
    </tr>
  `).join("");
}

function runOvScanner() {
  const settings = ovGetSettings();
  const analyzed = ovUniverse.map((stock) => analyzeOvStock(stock, settings));
  renderOvPrompt(settings);
  renderOv(analyzed);
}

Object.values(ovInputs).forEach((input) => {
  input.addEventListener("input", runOvScanner);
});

ovResetButton.addEventListener("click", () => {
  Object.entries(ovDefaults).forEach(([key, value]) => {
    ovInputs[key].value = value;
  });
  runOvScanner();
});

ovCopyPromptButton.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(ovExecutionPrompt.value);
    ovCopyPromptButton.textContent = "Copied";
    setTimeout(() => {
      ovCopyPromptButton.textContent = "Copy Prompt";
    }, 1200);
  } catch (error) {
    ovCopyPromptButton.textContent = "Copy Failed";
    setTimeout(() => {
      ovCopyPromptButton.textContent = "Copy Prompt";
    }, 1200);
  }
});

runOvScanner();
